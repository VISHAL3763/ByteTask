
import img1 from "../../public/images/allbag.png"
import img2 from "../../public/images/Frame 50.png"
import img3 from "../../public/images/Frame 49.png"
import img4 from "../../public/images/Frame 13.png"
import img5 from "../../public/images/Frame 49(1).png"
import img6 from "../../public/images/Frame 49(2).png"
import img7 from "../../public/images/Frame 22.png"
import img8 from "../../public/images/Frame 20.png"
import img9 from "../../public/images/Frame 46.png"



const Data = [
    {
        icon: img1,
        title: "all bags"
    },
    {
        icon: img2,
        title: "vanity bags"
    },
    {
        icon: img3,
        title: "tote bag"
    },
    {
        icon: img4,
        title: "duffle bag"
    },
    {
        icon: img5,
        title: "laptop sleeve"
    },
    {
        icon: img6,
        title: "messanger bags"
    },
    {
        icon: img7,
        title: "slings bags"
    },
    {
        icon: img8,
        title: "handbags"
    },
    {
        icon: img9,
        title: "bucket bags"
    },
]

export default Data