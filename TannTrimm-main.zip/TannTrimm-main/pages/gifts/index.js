import React from 'react'

const gifts = () => {
    return (
        <div>gifts</div>
    )
}

export default gifts