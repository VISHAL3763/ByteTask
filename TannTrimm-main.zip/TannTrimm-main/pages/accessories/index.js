import React from 'react'

const accessories = () => {
    return (
        <div>accessories</div>
    )
}

export default accessories