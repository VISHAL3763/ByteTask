import React from 'react'

const travels = () => {
    return (
        <div>travel</div>
    )
}

export default travels