import React from 'react'

const jewelerys = () => {
    return (
        <div>jewelery</div>
    )
}

export default jewelerys