import React from 'react'

const bags = () => {
    return (
        <div>bags</div>
    )
}

export default bags
